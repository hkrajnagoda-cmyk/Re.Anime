# In-Site Video Playback

The watch page now shows only the selected anime, its episodes and an inline video player. AnimeSalt details pages, unrelated recommendations and external streaming-search buttons have been removed from this flow.

## How It Works

- `src/streaming/animesalt-catalog.json` maps exact titles to first-season episode pages. `src/streaming/animesalt-players.json` maps those pages to the video-only iframe URLs published inside their native player container.
- The player is loaded only after **Play episode** is clicked. It never embeds an `/episode/` or `/series/` page and does not load other anime as a fallback.
- Server 1 and Server 2 select video-only players for the same episode. Next/previous episode, retry, stop and fullscreen remain on the Kokomi watch page.
- Unavailable titles show an inline unavailable state, not a redirect or an unrelated video.
- Languages, quality, ads, regional availability and media playback remain controlled by the embedded video provider. Iframe load events alone cannot confirm that a video is playing.
- The sandbox permits scripts, provider storage and media presentation, but not forms, popups, downloads or top-level redirects. No raw media, manifests or decryption keys are extracted, proxied or rehosted. Provider embedding restrictions are respected.
- The preferred server and manually marked episode progress stay in browser local storage. Previously saved external-source preferences are no longer used.

## Refresh And Verify

Run `node scripts/sync-animesalt.mjs` to refresh title/episode page links, then `node scripts/sync-animesalt-players.mjs` to index the published video-only iframe URLs. Both scripts make sequential public-page requests without proxying media. The player indexer also accepts `--offset`, `--limit` and `--output` arguments for separate batches. Review title mappings before adding catalog entries.

Run `npx playwright install --with-deps chromium` once, then `npx playwright test` for the regression suite. Set `ANIMESALT_LIVE=1` to include a live video-only playback smoke test. A sample playback test does not verify every catalog video and depends on provider availability.

Run `npx tsc --noEmit` and `npm run build` to verify the production bundle. A deployment Content Security Policy must allow the reviewed video origins `https://ravok.buzz` and `https://animesalt.cx` in `frame-src`. Do not strip or bypass provider restrictions. Verify distribution rights and provider terms before publishing.