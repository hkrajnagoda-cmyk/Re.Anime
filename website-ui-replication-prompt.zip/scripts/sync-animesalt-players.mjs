import { readFile, mkdir, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("../", import.meta.url));
const catalog = JSON.parse(await readFile(resolve(root, "src/streaming/animesalt-catalog.json"), "utf8"));
const options = Object.fromEntries(process.argv.slice(2).map((arg) => arg.replace(/^--/, "").split("=")));
const allEpisodes = Object.values(catalog.titles).flatMap((title) => title.episodes);
const offset = Number(options.offset ?? 0);
const limit = Number(options.limit ?? allEpisodes.length);
const output = resolve(root, options.output ?? "src/streaming/animesalt-players.json");
if (!Number.isInteger(offset) || offset < 0 || !Number.isInteger(limit) || limit < 1) throw new Error("Invalid batch range.");

const allowedOrigins = new Set(["https://ravok.buzz", catalog.origin]);

function readEmbed(tag) {
  const attributes = Object.fromEntries([...tag.matchAll(/([\w-]+)\s*=\s*(["'])(.*?)\2/g)].map((match) => [match[1], match[3]]));
  const value = attributes.src || attributes["data-src"];
  if (!value) return undefined;
  try {
    const url = new URL(value.replace(/&amp;/g, "&"), catalog.origin);
    if (!allowedOrigins.has(url.origin)) return undefined;
    if (url.origin === "https://ravok.buzz" && /^\/video\/[a-f\d]{32}\/?$/i.test(url.pathname)) return url.href;
    if (url.origin === catalog.origin && url.pathname === "/wp-content/themes/torofilm/public/plyr/player.php" && url.searchParams.has("data")) return url.href;
  } catch { return undefined; }
  return undefined;
}

const episodes = {};
let successful = 0;
for (const [index, episode] of allEpisodes.slice(offset, offset + limit).entries()) {
  try {
    const response = await fetch(episode.pageUrl, { signal: AbortSignal.timeout(15000) });
    if (!response.ok || response.url !== episode.pageUrl) throw new Error(`HTTP ${response.status} or unexpected redirect`);
    const html = await response.text();
    const playerMarkup = html.match(/<aside\b[^>]*\bid=["']aa-options["'][^>]*>([\s\S]*?)<\/aside>/i)?.[1];
    if (!playerMarkup) throw new Error("No native video player container");
    // Copy only the published video iframe URL, never the provider's page HTML or media payload.
    const urls = [...new Set([...playerMarkup.matchAll(/<iframe\b[^>]*>/gi)].map(([tag]) => readEmbed(tag)).filter(Boolean))];
    if (!urls.length) throw new Error("No supported video-only iframe");
    episodes[episode.pageUrl] = {
      checkedAt: new Date().toISOString(),
      players: urls.map((embedUrl, serverIndex) => ({ id: `server-${serverIndex + 1}`, label: `Server ${serverIndex + 1}`, embedUrl })),
    };
    successful++;
  } catch (error) {
    console.log(`SKIP ${episode.pageUrl}: ${error.message}`);
  }
  if ((index + 1) % 20 === 0) console.log(`Indexed ${index + 1}/${Math.min(limit, allEpisodes.length - offset)} pages (${successful} with players)`);
  await new Promise((done) => setTimeout(done, 200));
}

if (!successful) throw new Error("No video players verified; existing manifest was not changed.");
await mkdir(dirname(output), { recursive: true });
await writeFile(output, JSON.stringify({ schemaVersion: 1, checkedAt: new Date().toISOString(), episodes }, null, 2) + "\n");
console.log(`Saved ${successful} video-only episode entries to ${options.output ?? "src/streaming/animesalt-players.json"}`);