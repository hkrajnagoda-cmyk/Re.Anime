import { mkdir, writeFile } from "node:fs/promises";

const origin = "https://animesalt.cx";
const titles = {
  "attack-on-titan": "attack-on-titan",
  "fullmetal-alchemist-brotherhood": "fullmetal-alchemist-brotherhood",
  "bleach-thousand-year-blood-war": "bleach-thousand-year-blood-war",
  "hunter-x-hunter": "hunter-x-hunter",
  "death-note": "death-note",
  "vinland-saga": "vinland-saga",
  "dragon-ball-z": "dragon-ball-z",
  "naruto-shippuden": "naruto-shippuden",
  "demon-slayer": "demon-slayer",
  "jojos-bizarre-adventure": "jojos-bizarre-adventure",
  "hells-paradise": "hells-paradise",
  "redo-of-healer": "redo-of-healer",
  "oshi-no-ko": "oshi-no-ko",
  "heavenly-delusion": "heavenly-delusion",
  "one-piece-fish-man-island": "one-piece-log-fish-man-island-saga",
  "alya-sometimes-hides-her-feelings": "alya-sometimes-hides-her-feelings-in-russian",
  "tales-of-wedding-rings": "tales-of-wedding-rings",
  "solo-leveling": "solo-leveling",
  "kaiju-no-8": "kaiju-no-8",
  "frieren-beyond-journeys-end": "frieren-beyond-journeys-end",
  "jujutsu-kaisen": "jujutsu-kaisen",
  "spy-x-family": "spy-x-family",
  "chainsaw-man": "chainsaw-man",
  "blue-lock": "blue-lock",
};

const catalog = {};

// Index public page links only. Never extract, proxy, or rehost media files.
for (const [animeId, slug] of Object.entries(titles)) {
  const seriesUrl = `${origin}/series/${slug}/`;
  try {
    const response = await fetch(seriesUrl, { signal: AbortSignal.timeout(20000) });
    if (!response.ok || new URL(response.url).pathname !== `/series/${slug}/`) {
      console.log(`SKIP ${animeId}: page unavailable (${response.status})`);
      continue;
    }
    const html = await response.text();
    const episodes = new Map();
    const links = html.matchAll(/href=["'](https:\/\/animesalt\.cx\/episode\/([^"']+)-1x(\d+)\/)["']/g);
    for (const [, pageUrl, episodeSlug, rawNumber] of links) {
      if (episodeSlug !== slug) continue;
      const number = Number(rawNumber);
      if (Number.isInteger(number) && number > 0) episodes.set(number, { number, pageUrl });
    }
    if (!episodes.size) {
      console.log(`SKIP ${animeId}: no matching first-season episode links`);
      continue;
    }
    const seasonCount = new Set([...html.matchAll(/data-season=["'](\d+)["']/g)].map((match) => match[1])).size;
    catalog[animeId] = {
      seriesUrl,
      season: 1,
      seasonCount: Math.max(1, seasonCount),
      episodes: [...episodes.values()].sort((a, b) => a.number - b.number),
    };
    console.log(`OK ${animeId}: ${episodes.size} episode links`);
  } catch (error) {
    console.log(`SKIP ${animeId}: ${error.message}`);
  }
  await new Promise((resolve) => setTimeout(resolve, 250));
}

if (!Object.keys(catalog).length) throw new Error("No source pages were verified; keeping the existing catalog.");

await mkdir(new URL("../src/streaming/", import.meta.url), { recursive: true });
await writeFile(
  new URL("../src/streaming/animesalt-catalog.json", import.meta.url),
  JSON.stringify({ origin, checkedAt: new Date().toISOString(), titles: catalog }, null, 2) + "\n",
);