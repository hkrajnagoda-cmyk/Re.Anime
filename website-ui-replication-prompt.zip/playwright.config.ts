import { defineConfig } from "@playwright/test";

const baseURL = process.env.KOKOMI_BASE_URL ?? "http://localhost:5173";

export default defineConfig({
  testDir: "./tests",
  timeout: 40000,
  expect: { timeout: 8000 },
  workers: 1,
  reporter: "list",
  use: {
    baseURL,
    viewport: { width: 1440, height: 1000 },
    ignoreHTTPSErrors: true,
    screenshot: "only-on-failure",
  },
  webServer: process.env.KOKOMI_BASE_URL ? undefined : {
    command: "npm run dev -- --host 127.0.0.1 --port 5173",
    url: baseURL,
    reuseExistingServer: true,
  },
});