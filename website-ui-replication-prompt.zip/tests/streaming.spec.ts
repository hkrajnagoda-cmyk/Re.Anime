import { readFileSync } from "node:fs";
import { expect, test, type Page } from "@playwright/test";

const animePath = "/#/anime/demon-slayer";
const manifest = JSON.parse(readFileSync("src/streaming/animesalt-players.json", "utf8")) as {
  episodes: Record<string, { players: Array<{ id: string; label: string; embedUrl: string }> }>;
};
const catalog = JSON.parse(readFileSync("src/streaming/animesalt-catalog.json", "utf8")) as {
  titles: Record<string, { episodes: Array<{ number: number; pageUrl: string }> }>;
};
const embedFor = (episode: number, server = 0) => manifest.episodes[`https://animesalt.cx/episode/demon-slayer-1x${episode}/`].players[server].embedUrl;
const videoPattern = /https:\/\/(?:ravok\.buzz\/video\/|animesalt\.cx\/wp-content\/themes\/torofilm\/public\/plyr\/player\.php)/;

async function mockVideoFrames(page: Page) {
  await page.route(videoPattern, (route) => route.fulfill({
    contentType: "text/html", body: "<!doctype html><html><body>Video-only test fixture</body></html>",
  }));
}

test("every indexed episode has only reviewed video-only player URLs", () => {
  const episodes = Object.values(catalog.titles).flatMap((title) => title.episodes);
  expect(episodes.length).toBeGreaterThan(400);
  for (const episode of episodes) {
    const players = manifest.episodes[episode.pageUrl]?.players;
    expect(players?.length).toBeGreaterThan(0);
    for (const player of players) {
      const url = new URL(player.embedUrl);
      expect(url.protocol).toBe("https:");
      expect(["https://ravok.buzz", "https://animesalt.cx"]).toContain(url.origin);
      expect(url.pathname).not.toMatch(/^\/(?:episode|series)\//);
      expect(url.origin === "https://ravok.buzz"
        ? /^\/video\/[a-f\d]{32}$/i.test(url.pathname)
        : url.pathname === "/wp-content/themes/torofilm/public/plyr/player.php").toBe(true);
    }
  }
});

test("watch page shows only the selected anime and waits for play consent", async ({ page }) => {
  const providerRequests: string[] = [];
  page.on("request", (request) => {
    if (videoPattern.test(request.url()) || /^https:\/\/animesalt\.cx\/(episode|series)\//.test(request.url())) providerRequests.push(request.url());
  });
  await page.addInitScript(() => localStorage.setItem("kokomi-streaming-source", JSON.stringify("crunchyroll")));
  await page.goto(animePath);
  await expect(page.locator(".watch-page h1")).toHaveText("Demon Slayer: Kimetsu no Yaiba");
  await expect(page.getByRole("button", { name: "Play episode", exact: true })).toBeVisible();
  await expect(page.getByRole("button", { name: "Server 1", exact: true })).toHaveAttribute("aria-pressed", "true");
  await expect(page.locator(".animesalt-frame")).toHaveCount(0);
  await expect(page.locator(".watch-page .updated-card, .watch-page .detail-related")).toHaveCount(0);
  await expect(page.locator('.watch-page a[href^="http"]')).toHaveCount(0);
  await expect(page.locator(".watch-page")).not.toContainText("Crunchyroll");
  expect(providerRequests).toEqual([]);
});

test("episode selection replaces only the video while keeping the site URL", async ({ page }) => {
  await mockVideoFrames(page);
  await page.goto(animePath);
  await page.getByRole("button", { name: "Select episode 2", exact: true }).click();
  await page.getByRole("button", { name: "Play episode", exact: true }).click();
  await expect(page.locator(".animesalt-frame")).toHaveAttribute("src", embedFor(2));
  await page.getByRole("button", { name: "Next episode", exact: true }).click();
  await expect(page.locator(".animesalt-frame")).toHaveAttribute("src", embedFor(3));
  await expect(page.locator(".watch-heading-row")).toContainText("Episode 3");
  await page.getByRole("button", { name: "Previous episode", exact: true }).click();
  await expect(page.locator(".animesalt-frame")).toHaveAttribute("src", embedFor(2));
  await expect(page).toHaveURL(new RegExp("/#/anime/demon-slayer$"));
  await page.getByRole("button", { name: "Select episode 26", exact: true }).click();
  await expect(page.getByRole("button", { name: "Next episode", exact: true })).toBeDisabled();
  await page.getByRole("button", { name: "Stop video", exact: true }).click();
  await expect(page.locator(".animesalt-frame")).toHaveCount(0);
});

test("switching servers stays inline and remembers the preferred server", async ({ page }) => {
  await mockVideoFrames(page);
  await page.goto(animePath);
  await page.getByRole("button", { name: "Play episode", exact: true }).click();
  await expect(page.locator(".animesalt-frame")).toHaveAttribute("src", embedFor(1));
  await expect(page.locator(".source-loading")).toHaveCount(0);
  await page.locator(".animesalt-frame").evaluate((frame) => frame.setAttribute("data-instance", "original"));
  await page.getByRole("button", { name: "Server 1", exact: true }).click();
  await expect(page.locator(".source-loading")).toHaveCount(0);
  await expect(page.locator(".animesalt-frame")).toHaveAttribute("data-instance", "original");
  await page.getByRole("button", { name: "Server 2", exact: true }).click();
  await expect(page.locator(".animesalt-frame")).toHaveAttribute("src", embedFor(1, 1));
  await expect(page.locator('.streaming-player a[href^="http"]')).toHaveCount(0);
  await page.reload();
  await expect(page.getByRole("button", { name: "Server 2", exact: true })).toHaveAttribute("aria-pressed", "true");
  await expect(page.locator(".animesalt-frame")).toHaveCount(0);
  expect(await page.evaluate(() => JSON.parse(localStorage.getItem("kokomi-video-server")!))).toBe("server-2");
});

test("missing titles do not redirect or substitute another anime", async ({ page }) => {
  await page.goto("/#/anime/one-piece-fish-man-island");
  await expect(page.getByRole("heading", { name: "Episode unavailable" })).toBeVisible();
  await expect(page.locator(".watch-page h1")).toHaveText("One Piece Log: Fish-Man Island Saga");
  await expect(page.locator(".animesalt-frame")).toHaveCount(0);
  await expect(page.getByRole("button", { name: "Mark episode as watched" })).toBeDisabled();
  await expect(page.locator('.watch-page a[href^="http"]')).toHaveCount(0);
  await expect(page.getByRole("button", { name: "Next episode", exact: true })).toBeDisabled();
});

test("episode progress remains saved after reload", async ({ page }) => {
  await page.goto(animePath);
  await page.getByRole("button", { name: "Select episode 3", exact: true }).click();
  await page.getByRole("button", { name: "Mark episode as watched" }).click();
  await expect(page.locator(".episode-browser-head")).toContainText("1/26 watched");
  await page.reload();
  await expect(page.getByRole("button", { name: "Select episode 3", exact: true })).toHaveClass(/watched/);
  await expect(page.locator(".episode-browser-head")).toContainText("1/26 watched");
});

test("slow video frames can be retried and stopped without leaving Kokomi", async ({ page }) => {
  await page.clock.install();
  await page.route(videoPattern, () => {});
  await page.goto(animePath);
  await page.getByRole("button", { name: "Play episode", exact: true }).click();
  await page.clock.fastForward(17000);
  await expect(page.locator(".source-slow-notice")).toBeVisible();
  await expect(page.locator(".source-slow-notice")).toContainText("stay on this page");
  await page.getByRole("button", { name: "Retry", exact: true }).click();
  await expect(page.locator(".source-loading")).toBeVisible();
  await page.getByRole("button", { name: "Stop video", exact: true }).click();
  await expect(page.locator(".animesalt-frame")).toHaveCount(0);
  await expect(page).toHaveURL(new RegExp("/#/anime/demon-slayer$"));
});

test("video sandbox blocks popups and top-level navigation", async ({ page, context }) => {
  await page.route(videoPattern, (route) => route.fulfill({
    contentType: "text/html",
    body: `<button onclick="window.open('https://example.com/');try{window.top.location.href='https://example.com/'}catch(e){}">Attempt external navigation</button>`,
  }));
  await page.goto(animePath);
  await page.getByRole("button", { name: "Play episode", exact: true }).click();
  await page.frameLocator(".animesalt-frame").getByRole("button", { name: "Attempt external navigation" }).click();
  expect(context.pages()).toHaveLength(1);
  await expect(page).toHaveURL(new RegExp("/#/anime/demon-slayer$"));
  await expect(page.locator(".animesalt-frame")).toHaveAttribute("sandbox", "allow-scripts allow-same-origin allow-presentation");
});

test("mobile player remains visible, responsive and fullscreen-capable", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto(animePath);
  await expect(page.getByRole("button", { name: "Play episode", exact: true })).toBeInViewport();
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(390);
  await page.getByRole("button", { name: "Player fullscreen", exact: true }).click();
  await expect(page.locator(".source-player-container")).toHaveJSProperty("clientWidth", 390);
  await expect(page.getByRole("button", { name: "Exit player fullscreen", exact: true })).toBeVisible();
  await page.getByRole("button", { name: "Exit player fullscreen", exact: true }).click();
});

test("live video-only player advances playback without a provider details frame", async ({ page }) => {
  test.skip(process.env.ANIMESALT_LIVE !== "1", "Enable the external-video smoke test with ANIMESALT_LIVE=1.");
  test.setTimeout(90000);
  await page.goto(animePath);
  await page.getByRole("button", { name: "Play episode", exact: true }).click();
  for (const episode of [1, 2]) {
    if (episode > 1) await page.getByRole("button", { name: "Next episode", exact: true }).click();
    await expect(page.locator(".animesalt-frame")).toHaveAttribute("src", embedFor(episode));
    await expect.poll(async () => {
      const frame = page.frames().find((item) => item.url() === embedFor(episode));
      if (!frame) return false;
      try {
        return await frame.locator("video").evaluateAll((videos) => videos.some((video) => !video.paused && video.currentTime > 2 && video.readyState >= 2));
      } catch { return false; }
    }, { timeout: 35000, intervals: [1000, 2000, 3000] }).toBe(true);
    expect(page.frames().some((frame) => /https:\/\/animesalt\.cx\/(episode|series)\//.test(frame.url()))).toBe(false);
    await expect(page).toHaveURL(new RegExp("/#/anime/demon-slayer$"));
  }
});