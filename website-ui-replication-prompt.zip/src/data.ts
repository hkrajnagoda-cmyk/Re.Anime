export type Anime = {
  id: string;
  title: string;
  image: number;
  year: number;
  rating: number;
  episodes: number;
  duration: number;
  type: "TV" | "Movie";
  genres: string[];
  age?: string;
  description: string;
};

const assetRoot = "https://www.soulknightweb.com/kokomi.soulknightweb.com";
export const animeImage = (image: number | string) =>
  `${assetRoot}/images/animes/${image}.jpg`;
export const appImage = (image: number) =>
  `${assetRoot}/images/tv-download-slider/${image}.jpg`;

export const animeCatalog: Anime[] = [
  {
    id: "attack-on-titan",
    title: "Attack on Titan",
    image: 30,
    year: 2024,
    rating: 4.9,
    episodes: 16,
    duration: 25,
    type: "TV",
    genres: ["Action", "Drama", "Fantasy"],
    age: "18+",
    description:
      "Humanity's last cities stand behind enormous walls. Eren Yeager and the Scout Regiment risk everything to uncover the truth beyond them and win back freedom.",
  },
  {
    id: "fullmetal-alchemist-brotherhood",
    title: "Fullmetal Alchemist: Brotherhood",
    image: 28,
    year: 2024,
    rating: 4.9,
    episodes: 16,
    duration: 25,
    type: "TV",
    genres: ["Action", "Adventure", "Fantasy"],
    description:
      "Two brothers pay a terrible price for forbidden alchemy. Their search for the Philosopher's Stone reveals a conspiracy that reaches across their entire nation.",
  },
  {
    id: "bleach-thousand-year-blood-war",
    title: "Bleach: Thousand-Year Blood War",
    image: 43,
    year: 2024,
    rating: 4.8,
    episodes: 16,
    duration: 25,
    type: "TV",
    genres: ["Action", "Adventure", "Supernatural"],
    description:
      "Ichigo Kurosaki returns to the battlefield as the Wandenreich declares war on the Soul Society and old secrets surrounding the Quincy finally emerge.",
  },
  {
    id: "hunter-x-hunter",
    title: "Hunter x Hunter",
    image: 11,
    year: 2024,
    rating: 4.8,
    episodes: 16,
    duration: 25,
    type: "TV",
    genres: ["Action", "Adventure", "Fantasy"],
    description:
      "Gon Freecss leaves home to become a Hunter and find his father. Alongside Killua, Kurapika and Leorio, he discovers a world far bigger and stranger than he imagined.",
  },
  {
    id: "death-note",
    title: "Death Note",
    image: 34,
    year: 2024,
    rating: 4.8,
    episodes: 16,
    duration: 25,
    type: "TV",
    genres: ["Mystery", "Psychological", "Supernatural"],
    age: "18+",
    description:
      "A brilliant student finds a notebook that can end a life when a name is written in it. His idea of justice draws the attention of the equally brilliant detective L.",
  },
  {
    id: "vinland-saga",
    title: "Vinland Saga",
    image: 45,
    year: 2024,
    rating: 4.8,
    episodes: 16,
    duration: 25,
    type: "TV",
    genres: ["Action", "Adventure", "Drama"],
    age: "18+",
    description:
      "Raised amid the brutality of a Viking war, Thorfinn begins a long journey from revenge toward a land without violence and a new understanding of strength.",
  },
  {
    id: "dragon-ball-z",
    title: "Dragon Ball Z",
    image: 46,
    year: 2024,
    rating: 4.7,
    episodes: 16,
    duration: 25,
    type: "TV",
    genres: ["Action", "Adventure", "Comedy"],
    description:
      "Goku and his friends defend Earth from overwhelming enemies, discover Saiyan history and push beyond every limit in one of anime's defining adventures.",
  },
  {
    id: "naruto-shippuden",
    title: "Naruto: Shippuden",
    image: 48,
    year: 2024,
    rating: 4.7,
    episodes: 16,
    duration: 25,
    type: "TV",
    genres: ["Action", "Adventure", "Fantasy"],
    description:
      "Naruto returns after years of training to protect his friends, face the Akatsuki and bring Sasuke home while a larger conflict threatens every ninja village.",
  },
  {
    id: "demon-slayer",
    title: "Demon Slayer: Kimetsu no Yaiba",
    image: 7,
    year: 2024,
    rating: 4.8,
    episodes: 16,
    duration: 25,
    type: "TV",
    genres: ["Action", "Fantasy", "Supernatural"],
    description:
      "After his family is attacked, Tanjiro Kamado joins the Demon Slayer Corps and searches for a way to restore his sister Nezuko's humanity.",
  },
  {
    id: "jojos-bizarre-adventure",
    title: "JoJo's Bizarre Adventure",
    image: 55,
    year: 2024,
    rating: 4.6,
    episodes: 16,
    duration: 25,
    type: "TV",
    genres: ["Action", "Adventure", "Supernatural"],
    description:
      "Across generations, the Joestar family faces supernatural rivals with inventive abilities, unforgettable style and battles where wit matters as much as power.",
  },
  {
    id: "gintama-final",
    title: "Gintama Final",
    image: 3,
    year: 2024,
    rating: 4.2,
    episodes: 16,
    duration: 25,
    type: "TV",
    genres: ["Action", "Comedy", "Sci-Fi"],
    description:
      "Gintoki and the Yorozuya return for one last outrageous adventure, blending sharp comedy with a heartfelt farewell to the friends who made Edo home.",
  },
  {
    id: "hells-paradise",
    title: "Hell's Paradise",
    image: 6,
    year: 2024,
    rating: 4.2,
    episodes: 16,
    duration: 25,
    type: "TV",
    genres: ["Action", "Adventure", "Supernatural"],
    age: "18+",
    description:
      "A condemned ninja and his executioner travel to a mysterious island in search of the elixir of life, where beauty and danger exist side by side.",
  },
  {
    id: "redo-of-healer",
    title: "Redo of Healer",
    image: 12,
    year: 2024,
    rating: 4.2,
    episodes: 16,
    duration: 25,
    type: "TV",
    genres: ["Action", "Fantasy", "Drama"],
    age: "18+",
    description:
      "A healing magician uses his extraordinary power to rewind time and alter the course of a dark fantasy story. Recommended for mature audiences.",
  },
  {
    id: "oshi-no-ko",
    title: "Oshi no Ko",
    image: 20,
    year: 2024,
    rating: 4.6,
    episodes: 16,
    duration: 25,
    type: "TV",
    genres: ["Drama", "Mystery", "Supernatural"],
    description:
      "Behind the glow of Japan's entertainment industry, Aqua and Ruby Hoshino pursue their own ambitions while searching for the truth about their mother.",
  },
  {
    id: "heavenly-delusion",
    title: "Heavenly Delusion",
    image: 21,
    year: 2024,
    rating: 4.5,
    episodes: 16,
    duration: 25,
    type: "TV",
    genres: ["Adventure", "Mystery", "Sci-Fi"],
    description:
      "Two travelers cross a transformed Japan in search of a place called heaven, while children inside a protected facility begin to question their world.",
  },
  {
    id: "one-piece-fish-man-island",
    title: "One Piece Log: Fish-Man Island Saga",
    image: 130,
    year: 2024,
    rating: 4.9,
    episodes: 21,
    duration: 25,
    type: "TV",
    genres: ["Action", "Adventure", "Fantasy", "Shonen"],
    description:
      "Join Monkey D. Luffy and his lovable pirate crew as they discover the true meaning of power and justice in this great pirate era.",
  },
  {
    id: "alya-sometimes-hides-her-feelings",
    title: "Alya Sometimes Hides Her Feelings in Russian",
    image: 125,
    year: 2024,
    rating: 4.5,
    episodes: 12,
    duration: 24,
    type: "TV",
    genres: ["Comedy", "Romance", "School"],
    description:
      "Alya appears to be the perfect honor student, but she reveals her softer feelings in Russian—unaware that her seatmate Masachika understands every word.",
  },
  {
    id: "tales-of-wedding-rings",
    title: "Tales of Wedding Rings",
    image: 126,
    year: 2024,
    rating: 4.3,
    episodes: 12,
    duration: 24,
    type: "TV",
    genres: ["Action", "Fantasy", "Romance"],
    description:
      "Satou follows his childhood friend Hime into another world and inherits the power of the Ring King, beginning an adventure shaped by courage and devotion.",
  },
  {
    id: "solo-leveling",
    title: "Solo Leveling",
    image: 127,
    year: 2024,
    rating: 4.7,
    episodes: 12,
    duration: 24,
    type: "TV",
    genres: ["Action", "Adventure", "Fantasy"],
    description:
      "Known as the weakest hunter, Sung Jinwoo survives a deadly double dungeon and gains a mysterious ability to level up without a visible limit.",
  },
  {
    id: "kaiju-no-8",
    title: "Kaiju No. 8",
    image: 128,
    year: 2024,
    rating: 4.6,
    episodes: 12,
    duration: 24,
    type: "TV",
    genres: ["Action", "Sci-Fi", "Shonen"],
    description:
      "Kafka Hibino finally gets another chance to join the Defense Force, but a startling transformation means he must hide the monster he has become.",
  },
  {
    id: "frieren-beyond-journeys-end",
    title: "Frieren: Beyond Journey's End",
    image: 129,
    year: 2024,
    rating: 4.9,
    episodes: 28,
    duration: 24,
    type: "TV",
    genres: ["Adventure", "Drama", "Fantasy"],
    description:
      "An elven mage outlives the hero's party she once traveled with and begins a quiet new journey to understand people, memory and the passing of time.",
  },
  {
    id: "jujutsu-kaisen",
    title: "Jujutsu Kaisen",
    image: 131,
    year: 2024,
    rating: 4.8,
    episodes: 24,
    duration: 24,
    type: "TV",
    genres: ["Action", "Supernatural", "Shonen"],
    description:
      "Yuji Itadori enters the hidden world of jujutsu sorcerers after becoming the vessel of a powerful curse and chooses to use his remaining time to help others.",
  },
  {
    id: "spy-x-family",
    title: "SPY x FAMILY",
    image: 132,
    year: 2024,
    rating: 4.7,
    episodes: 25,
    duration: 24,
    type: "TV",
    genres: ["Action", "Comedy", "Family"],
    description:
      "A spy, an assassin and a telepath pretend to be an ordinary family, each keeping a secret while their unexpected bond becomes genuinely meaningful.",
  },
  {
    id: "chainsaw-man",
    title: "Chainsaw Man",
    image: 133,
    year: 2024,
    rating: 4.6,
    episodes: 12,
    duration: 24,
    type: "TV",
    genres: ["Action", "Comedy", "Supernatural"],
    age: "18+",
    description:
      "Denji merges with his devil-dog companion Pochita and is recruited into Public Safety, where simple dreams collide with dangerous devils and difficult loyalties.",
  },
  {
    id: "blue-lock",
    title: "Blue Lock",
    image: 134,
    year: 2024,
    rating: 4.5,
    episodes: 24,
    duration: 24,
    type: "TV",
    genres: ["Drama", "Shonen", "Sports"],
    description:
      "Japan gathers three hundred young strikers in an uncompromising training facility to create the world's most talented—and most ego-driven—forward.",
  },
];

export const getAnime = (idOrImage: string | number) =>
  typeof idOrImage === "number"
    ? animeCatalog.find((item) => item.image === idOrImage)
    : animeCatalog.find((item) => item.id === idOrImage);

export const trending = [
  "attack-on-titan",
  "fullmetal-alchemist-brotherhood",
  "bleach-thousand-year-blood-war",
  "hunter-x-hunter",
  "death-note",
  "vinland-saga",
  "dragon-ball-z",
  "naruto-shippuden",
  "demon-slayer",
  "jojos-bizarre-adventure",
].map((id) => getAnime(id)!);

export const heroSlides = [
  getAnime("demon-slayer")!,
  getAnime("alya-sometimes-hides-her-feelings")!,
  getAnime("tales-of-wedding-rings")!,
];

export const recentlyUpdated = [
  "frieren-beyond-journeys-end",
  "blue-lock",
  "gintama-final",
  "jujutsu-kaisen",
  "spy-x-family",
  "hells-paradise",
  "demon-slayer",
  "chainsaw-man",
  "one-piece-fish-man-island",
  "death-note",
  "hunter-x-hunter",
  "redo-of-healer",
  "vinland-saga",
  "dragon-ball-z",
  "naruto-shippuden",
  "fullmetal-alchemist-brotherhood",
  "bleach-thousand-year-blood-war",
  "jojos-bizarre-adventure",
  "solo-leveling",
  "oshi-no-ko",
  "heavenly-delusion",
  "alya-sometimes-hides-her-feelings",
  "tales-of-wedding-rings",
  "kaiju-no-8",
].map((id) => getAnime(id)!);

export const topTen = {
  Today: ["one-piece-fish-man-island", 19, 3, 27, 28, 29, 30, 31, 32, 11],
  Week: ["frieren-beyond-journeys-end", 7, 34, 35, 37, 38, 39, 40, 41, 43],
  Month: ["demon-slayer", 5, 6, 8, 9, 10, 12, 13, 14, 17],
} as const;

export const collections = {
  "Top Airing": [26, 3, 27, 28, 29, 30, 31, 32, 11, 19],
  "Most Popular": [33, 7, 34, 35, 37, 38, 39, 40, 41, 43],
  "Most Favorite": [34, 30, 33, 45, 46, 44, 47, 49, 50, 51],
  "Latest Completed": [2, 5, 6, 8, 9, 10, 12, 13, 14, 17],
};

export const recentlyAdded = [125, 126, 127, 128, 129, 131, 133, 132, 134, 135, 136];

export const genreCards = [
  { name: "Action", image: 30 },
  { name: "Adventure", image: 45 },
  { name: "Comedy", image: 3 },
  { name: "Drama", image: 20 },
  { name: "Fantasy", image: 21 },
  { name: "Romance", image: 125 },
  { name: "Sci-Fi", image: 128 },
  { name: "Supernatural", image: 7 },
];

export const scheduleShows = [
  { animeId: "one-piece-fish-man-island", time: "09:30", episode: 12 },
  { animeId: "demon-slayer", time: "11:00", episode: 8 },
  { animeId: "kaiju-no-8", time: "13:30", episode: 10 },
  { animeId: "alya-sometimes-hides-her-feelings", time: "16:00", episode: 7 },
  { animeId: "frieren-beyond-journeys-end", time: "18:30", episode: 24 },
  { animeId: "solo-leveling", time: "21:00", episode: 11 },
];

export const trailerItems = [
  { animeId: "one-piece-fish-man-island", label: "Official Trailer", date: "Oct 28, 2024" },
  { animeId: "solo-leveling", label: "Season 2 Teaser", date: "Oct 26, 2024" },
  { animeId: "demon-slayer", label: "Hashira Training Arc", date: "Oct 22, 2024" },
  { animeId: "kaiju-no-8", label: "Main Trailer", date: "Oct 20, 2024" },
  { animeId: "alya-sometimes-hides-her-feelings", label: "Character PV", date: "Oct 18, 2024" },
  { animeId: "frieren-beyond-journeys-end", label: "Journey Continues", date: "Oct 15, 2024" },
  { animeId: "jujutsu-kaisen", label: "Official Preview", date: "Oct 12, 2024" },
  { animeId: "spy-x-family", label: "Family Mission PV", date: "Oct 08, 2024" },
];
