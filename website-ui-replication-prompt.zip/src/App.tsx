import {
  ArrowRight,
  ArrowUp,
  Bell,
  BellRing,
  Bookmark,
  CalendarDays,
  Captions,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Clock3,
  Download,
  Eye,
  Camera,
  Globe2,
  MessageCircle,
  ListFilter,
  Mail,
  Menu,
  Mic2,
  Play,
  Plus,
  Radio,
  Search,
  Send,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Star,
  Tv,
  UserRound,
  Users,
  X,
  Zap,
} from "lucide-react";
import {
  FormEvent,
  PointerEvent as ReactPointerEvent,
  ReactNode,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import LegalPage, { LegalTopic } from "./LegalPage";
import StreamingPlayer from "./streaming/StreamingPlayer";
import { getSourceEpisodes } from "./streaming/providers";
import {
  Anime,
  animeCatalog,
  animeImage,
  appImage,
  collections,
  genreCards,
  getAnime,
  heroSlides,
  recentlyAdded,
  recentlyUpdated,
  scheduleShows,
  topTen,
  trailerItems,
  trending,
} from "./data";

const trailerSearch = (title: string) =>
  `https://www.youtube.com/results?search_query=${encodeURIComponent(`${title} official anime trailer`)}`;

function usePersistentState<T>(key: string, initialValue: T) {
  const [value, setValue] = useState<T>(() => {
    try {
      const saved = localStorage.getItem(key);
      return saved ? (JSON.parse(saved) as T) : initialValue;
    } catch {
      return initialValue;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {
      // The interface remains functional if storage is unavailable.
    }
  }, [key, value]);

  return [value, setValue] as const;
}

function Logo({ onClick }: { onClick?: () => void }) {
  return (
    <a className="brand" href="#home" onClick={onClick} aria-label="Kokomi home">
      <span className="brand-mark" aria-hidden="true">
        <span />
        <span />
      </span>
      <span className="brand-name">Kokomi</span>
      <span className="brand-dot">.</span>
    </a>
  );
}

function IconButton({
  label,
  children,
  onClick,
  className = "",
}: {
  label: string;
  children: ReactNode;
  onClick?: () => void;
  className?: string;
}) {
  return (
    <button className={`icon-button ${className}`} type="button" aria-label={label} title={label} onClick={onClick}>
      {children}
    </button>
  );
}

function SectionHeading({ children, action }: { children: ReactNode; action?: ReactNode }) {
  return (
    <div className="heading-section">
      <h2>{children}</h2>
      {action}
    </div>
  );
}

type HeaderProps = {
  watchlistCount: number;
  onOpenWatchlist: () => void;
  onOpenAnime: (anime: Anime) => void;
  onSelectGenre: (genre: string) => void;
};

function Header({ watchlistCount, onOpenWatchlist, onOpenAnime, onSelectGenre }: HeaderProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [genreOpen, setGenreOpen] = useState(false);
  const [query, setQuery] = useState("");
  const searchRef = useRef<HTMLInputElement>(null);

  const results = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    if (!normalized) return [];
    return animeCatalog
      .filter(
        (anime) =>
          anime.title.toLowerCase().includes(normalized) ||
          anime.genres.some((genre) => genre.toLowerCase().includes(normalized)),
      )
      .slice(0, 6);
  }, [query]);

  useEffect(() => {
    const handleKeys = (event: KeyboardEvent) => {
      if (event.key === "/" && !["INPUT", "TEXTAREA"].includes((event.target as HTMLElement).tagName)) {
        event.preventDefault();
        setSearchOpen(true);
        window.setTimeout(() => searchRef.current?.focus(), 30);
      }
      if (event.key === "Escape") {
        setSearchOpen(false);
        setMobileOpen(false);
        setGenreOpen(false);
      }
    };
    window.addEventListener("keydown", handleKeys);
    return () => window.removeEventListener("keydown", handleKeys);
  }, []);

  useEffect(() => {
    document.body.classList.toggle("no-scroll", mobileOpen || searchOpen);
    return () => document.body.classList.remove("no-scroll");
  }, [mobileOpen, searchOpen]);

  const chooseAnime = (anime: Anime) => {
    onOpenAnime(anime);
    setQuery("");
    setSearchOpen(false);
  };

  const chooseGenre = (genre: string) => {
    onSelectGenre(genre);
    setGenreOpen(false);
    setMobileOpen(false);
  };

  const submitSearch = (event: FormEvent) => {
    event.preventDefault();
    if (results[0]) chooseAnime(results[0]);
  };

  return (
    <>
      <header className="main-header">
        <div className="header-inner">
          <IconButton label="Open navigation" className="mobile-menu-trigger" onClick={() => setMobileOpen(true)}>
            <Menu size={23} />
          </IconButton>
          <Logo />
          <nav className="desktop-nav" aria-label="Main navigation">
            <a href="#home">Home</a>
            <a href="#recently-updated">Anime Series</a>
            <a href="#all-time">Movies</a>
            <div className="nav-dropdown">
              <button type="button" onClick={() => setGenreOpen((open) => !open)} aria-expanded={genreOpen}>
                Genres <ChevronDown size={14} className={genreOpen ? "rotate" : ""} />
              </button>
              {genreOpen && (
                <div className="genre-dropdown">
                  {genreCards.map((genre) => (
                    <button key={genre.name} type="button" onClick={() => chooseGenre(genre.name)}>
                      {genre.name}
                    </button>
                  ))}
                </div>
              )}
            </div>
            <a href="#community">Community</a>
            <a href="#schedule">Schedule</a>
          </nav>
          <div className="header-actions">
            <button className="search-trigger" type="button" onClick={() => setSearchOpen(true)} aria-label="Search anime">
              <Search size={19} />
              <span>Search</span>
              <kbd>/</kbd>
            </button>
            <button className="watchlist-trigger" type="button" onClick={onOpenWatchlist}>
              <Bookmark size={18} />
              <span>My List</span>
              {watchlistCount > 0 && <b>{watchlistCount}</b>}
            </button>
            <a className="join-button" href="#newsletter">
              <UserRound size={17} /> Join now
            </a>
          </div>
        </div>
      </header>

      {searchOpen && (
        <div className="search-overlay" role="dialog" aria-modal="true" aria-label="Search anime">
          <button className="overlay-dismiss" type="button" aria-label="Close search" onClick={() => setSearchOpen(false)} />
          <div className="search-panel">
            <div className="search-panel-top">
              <span>Find your next story</span>
              <IconButton label="Close search" onClick={() => setSearchOpen(false)}>
                <X size={22} />
              </IconButton>
            </div>
            <form className="search-form" onSubmit={submitSearch}>
              <Search size={25} />
              <input
                ref={searchRef}
                autoFocus
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search anime, genres..."
                aria-label="Search anime or genres"
              />
              {query && (
                <button type="button" onClick={() => setQuery("")} aria-label="Clear search">
                  <X size={19} />
                </button>
              )}
            </form>
            <div className="search-results" aria-live="polite">
              {!query && (
                <div className="search-suggestions">
                  <p>Popular searches</p>
                  <div>
                    {["One Piece", "Demon Slayer", "Fantasy", "Romance"].map((term) => (
                      <button key={term} type="button" onClick={() => setQuery(term)}>
                        {term}
                      </button>
                    ))}
                  </div>
                </div>
              )}
              {query && results.length === 0 && (
                <div className="search-empty">
                  <Search size={30} />
                  <h3>No anime found</h3>
                  <p>Try another title or a genre such as Action or Drama.</p>
                </div>
              )}
              {results.map((anime) => (
                <button className="search-result" type="button" key={anime.id} onClick={() => chooseAnime(anime)}>
                  <img src={animeImage(anime.image)} alt="" />
                  <span>
                    <strong>{anime.title}</strong>
                    <small>
                      {anime.year} · {anime.genres.slice(0, 2).join(" / ")}
                    </small>
                  </span>
                  <span className="search-rating">
                    <Star size={13} fill="currentColor" /> {anime.rating}
                  </span>
                  <ArrowRight size={18} />
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      <div className={`mobile-navigation ${mobileOpen ? "open" : ""}`} aria-hidden={!mobileOpen}>
        <button className="overlay-dismiss" type="button" aria-label="Close navigation" onClick={() => setMobileOpen(false)} />
        <aside>
          <div className="mobile-nav-head">
            <Logo onClick={() => setMobileOpen(false)} />
            <IconButton label="Close navigation" onClick={() => setMobileOpen(false)}>
              <X size={22} />
            </IconButton>
          </div>
          <button
            className="mobile-search"
            type="button"
            onClick={() => {
              setMobileOpen(false);
              setSearchOpen(true);
            }}
          >
            <Search size={18} /> Search anime
          </button>
          <nav aria-label="Mobile navigation">
            <a href="#home" onClick={() => setMobileOpen(false)}>Home <ChevronRight size={17} /></a>
            <a href="#recently-updated" onClick={() => setMobileOpen(false)}>Anime Series <ChevronRight size={17} /></a>
            <a href="#all-time" onClick={() => setMobileOpen(false)}>Movies <ChevronRight size={17} /></a>
            <a href="#community" onClick={() => setMobileOpen(false)}>Community <ChevronRight size={17} /></a>
            <a href="#schedule" onClick={() => setMobileOpen(false)}>Schedule <ChevronRight size={17} /></a>
          </nav>
          <div className="mobile-genres">
            <p>Browse by genre</p>
            <div>
              {genreCards.map((genre) => (
                <button type="button" key={genre.name} onClick={() => chooseGenre(genre.name)}>{genre.name}</button>
              ))}
            </div>
          </div>
          <button className="gradient-button mobile-list-button" type="button" onClick={() => { setMobileOpen(false); onOpenWatchlist(); }}>
            <Bookmark size={17} /> My List ({watchlistCount})
          </button>
        </aside>
      </div>
    </>
  );
}

function Hero({ onOpenAnime, onToggleList, watchlist }: { onOpenAnime: (anime: Anime) => void; onToggleList: (id: string) => void; watchlist: string[] }) {
  const [active, setActive] = useState(0);
  const [paused, setPaused] = useState(false);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const anime = heroSlides[active];

  useEffect(() => {
    if (paused) return;
    const interval = window.setInterval(() => setActive((index) => (index + 1) % heroSlides.length), 7000);
    return () => window.clearInterval(interval);
  }, [paused]);

  const handleTilt = (event: ReactPointerEvent<HTMLDivElement>) => {
    const bounds = event.currentTarget.getBoundingClientRect();
    setTilt({
      x: ((event.clientY - bounds.top) / bounds.height - 0.5) * -10,
      y: ((event.clientX - bounds.left) / bounds.width - 0.5) * 12,
    });
  };

  return (
    <section
      id="home"
      className="hero"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => { setPaused(false); setTilt({ x: 0, y: 0 }); }}
      aria-label="Trending anime"
    >
      <div className="hero-backgrounds" aria-hidden="true">
        {heroSlides.map((slide, index) => (
          <img key={slide.id} className={index === active ? "active" : ""} src={animeImage(slide.image)} alt="" />
        ))}
      </div>
      <div className="hero-shade" />
      <div className="hero-inner">
        <div className="hero-copy" key={anime.id}>
          <div className="eyebrow"><span>#{String(active + 1).padStart(2, "0")}</span> Trending</div>
          <h1>{anime.title}</h1>
          <div className="hero-meta">
            <span className="quality">HD</span>
            <span><Star size={14} fill="currentColor" /> {anime.rating}</span>
            <span>{anime.year}</span>
            <span>{anime.episodes} Episodes</span>
            <span>{anime.type}</span>
          </div>
          <div className="hero-genres">
            {anime.genres.map((genre) => <span key={genre}>{genre}</span>)}
          </div>
          <p>{anime.description}</p>
          <div className="hero-buttons">
            <button className="gradient-button" type="button" onClick={() => onOpenAnime(anime)}>
              <Play size={17} fill="currentColor" /> Watch now
            </button>
            <button className={`glass-button ${watchlist.includes(anime.id) ? "saved" : ""}`} type="button" onClick={() => onToggleList(anime.id)}>
              {watchlist.includes(anime.id) ? <Check size={18} /> : <Plus size={18} />}
              {watchlist.includes(anime.id) ? "In my list" : "Add to list"}
            </button>
          </div>
        </div>

        <div className="hero-visual">
          <div
            className="poster-stage"
            onPointerMove={handleTilt}
            onPointerLeave={() => setTilt({ x: 0, y: 0 })}
            style={{ transform: `rotateX(${tilt.x}deg) rotateY(${tilt.y}deg)` }}
          >
            <img className="poster-shadow-card card-three" src={animeImage(heroSlides[(active + 2) % 3].image)} alt="" />
            <img className="poster-shadow-card card-two" src={animeImage(heroSlides[(active + 1) % 3].image)} alt="" />
            <button type="button" className="hero-poster" onClick={() => onOpenAnime(anime)} aria-label={`Open ${anime.title}`}>
              <img key={anime.id} src={animeImage(anime.image)} alt={anime.title} />
              <span><Play size={22} fill="currentColor" /></span>
            </button>
          </div>
          <div className="community-card" id="community">
            <div className="community-icon"><Users size={21} /></div>
            <div>
              <strong>Kokomi Community</strong>
              <span><i /> 996 Online <b>·</b> 6069 Members</span>
            </div>
            <a href="#newsletter" aria-label="Join the Kokomi community"><ArrowRight size={18} /></a>
          </div>
        </div>
      </div>
      <div className="hero-controls">
        <div>
          {heroSlides.map((slide, index) => (
            <button
              key={slide.id}
              className={index === active ? "active" : ""}
              type="button"
              onClick={() => setActive(index)}
              aria-label={`Show ${slide.title}`}
              aria-current={index === active ? "true" : undefined}
            ><span /></button>
          ))}
        </div>
        <span>{String(active + 1).padStart(2, "0")} <i /> {String(heroSlides.length).padStart(2, "0")}</span>
      </div>
    </section>
  );
}

function Genres({ selected, onSelect }: { selected: string; onSelect: (genre: string) => void }) {
  const rail = useRef<HTMLDivElement>(null);
  const move = (direction: number) => rail.current?.scrollBy({ left: direction * 440, behavior: "smooth" });
  return (
    <section className="genres-section" aria-label="Browse genres">
      <div className="genre-rail" ref={rail}>
        {genreCards.map((genre) => (
          <button
            type="button"
            key={genre.name}
            className={`genre-card ${selected === genre.name ? "selected" : ""}`}
            onClick={() => {
              onSelect(selected === genre.name ? "All" : genre.name);
              document.getElementById("recently-updated")?.scrollIntoView({ behavior: "smooth" });
            }}
          >
            <img src={animeImage(genre.image)} alt="" />
            <span>{genre.name}</span>
            <ArrowRight size={16} />
          </button>
        ))}
      </div>
      <div className="rail-buttons">
        <IconButton label="Previous genres" onClick={() => move(-1)}><ChevronLeft size={20} /></IconButton>
        <IconButton label="Next genres" onClick={() => move(1)}><ChevronRight size={20} /></IconButton>
      </div>
    </section>
  );
}

function SaveButton({ anime, saved, onToggle, className = "" }: { anime: Anime; saved: boolean; onToggle: (id: string) => void; className?: string }) {
  return (
    <button
      type="button"
      className={`save-button ${saved ? "saved" : ""} ${className}`}
      onClick={(event) => { event.stopPropagation(); onToggle(anime.id); }}
      aria-label={saved ? `Remove ${anime.title} from my list` : `Add ${anime.title} to my list`}
      title={saved ? "Remove from My List" : "Add to My List"}
    >
      {saved ? <Check size={16} /> : <Plus size={16} />}
    </button>
  );
}

function Trending({ onOpenAnime, onToggleList, watchlist }: { onOpenAnime: (anime: Anime) => void; onToggleList: (id: string) => void; watchlist: string[] }) {
  const rail = useRef<HTMLDivElement>(null);
  const move = (direction: number) => rail.current?.scrollBy({ left: direction * Math.min(700, window.innerWidth * 0.75), behavior: "smooth" });
  return (
    <section className="section trending-section" id="trending">
      <SectionHeading action={
        <div className="heading-actions">
          <IconButton label="Previous trending anime" onClick={() => move(-1)}><ChevronLeft size={19} /></IconButton>
          <IconButton label="Next trending anime" onClick={() => move(1)}><ChevronRight size={19} /></IconButton>
        </div>
      }>Trending Now</SectionHeading>
      <div className="trending-rail" ref={rail}>
        {trending.map((anime, index) => (
          <article className="trend-card" key={anime.id}>
            <span className="trend-number">{String(index + 1).padStart(2, "0")}</span>
            <div className="trend-poster">
              <button type="button" onClick={() => onOpenAnime(anime)} aria-label={`View ${anime.title}`}>
                <img src={animeImage(anime.image)} alt={anime.title} loading="lazy" />
                <span className="poster-play"><Play size={19} fill="currentColor" /></span>
              </button>
              <SaveButton anime={anime} saved={watchlist.includes(anime.id)} onToggle={onToggleList} />
            </div>
            <button className="trend-title" type="button" onClick={() => onOpenAnime(anime)}>{anime.title}</button>
            <span className="trend-meta">{anime.genres[0]} · {anime.year}</span>
          </article>
        ))}
      </div>
    </section>
  );
}

function UpdatedCard({ anime, onOpen, onToggleList, saved }: { anime: Anime; onOpen: () => void; onToggleList: (id: string) => void; saved: boolean }) {
  return (
    <article className="updated-card">
      <div className="updated-poster">
        <button className="updated-main-link" type="button" onClick={onOpen} aria-label={`View ${anime.title}`}>
          <img src={animeImage(anime.image)} alt={anime.title} loading="lazy" />
          <span className="updated-overlay">
            <strong>{anime.title}</strong>
            <small>{anime.year} | {anime.duration} min / ep</small>
            <span className="overlay-stats">
              <i><Star size={11} fill="currentColor" /> {anime.rating}/5</i>
              <i><Tv size={11} /> {anime.episodes}</i>
              <i><Captions size={11} /> CC</i>
            </span>
            <span className="overlay-description">{anime.description}</span>
            <span className="overlay-watch"><Play size={13} fill="currentColor" /> View series</span>
          </span>
        </button>
        {anime.age && <span className="age-badge">{anime.age}</span>}
        <SaveButton anime={anime} saved={saved} onToggle={onToggleList} />
        <span className="type-badge">{anime.type}</span>
      </div>
      <button type="button" className="updated-title" onClick={onOpen}>{anime.title}</button>
      <div className="updated-subline"><span>{anime.genres[0]}</span><span>EP {anime.episodes}</span></div>
    </article>
  );
}

function TopTen({ onOpenAnime }: { onOpenAnime: (anime: Anime) => void }) {
  const [period, setPeriod] = useState<keyof typeof topTen>("Today");
  const entries = topTen[period];
  return (
    <section className="top-ten">
      <SectionHeading>Top 10</SectionHeading>
      <div className="period-tabs" role="tablist" aria-label="Top 10 time period">
        {(Object.keys(topTen) as Array<keyof typeof topTen>).map((tab) => (
          <button key={tab} type="button" role="tab" aria-selected={period === tab} className={period === tab ? "active" : ""} onClick={() => setPeriod(tab)}>{tab}</button>
        ))}
      </div>
      <div className="top-ten-grid" role="tabpanel" key={period}>
        {entries.map((entry, index) => {
          const anime = typeof entry === "string" ? getAnime(entry) : getAnime(entry);
          const image = index === 0 ? animeImage(`top-anime-banner-${period.toLowerCase()}`) : animeImage(typeof entry === "string" ? anime!.image : entry);
          const content = (
            <>
              <img src={image} alt={anime?.title || `Top ${period} anime ${index + 1}`} loading="lazy" />
              <span className="top-rank">{index + 1}</span>
              {anime && <span className="top-title">{anime.title}</span>}
            </>
          );
          return anime ? (
            <button className={`top-item ${index === 0 ? "top-feature" : ""}`} type="button" key={`${period}-${index}`} onClick={() => onOpenAnime(anime)}>{content}</button>
          ) : (
            <div className={`top-item ${index === 0 ? "top-feature" : ""}`} key={`${period}-${index}`}>{content}</div>
          );
        })}
      </div>
    </section>
  );
}

function RecentlyAdded({ onOpenAnime }: { onOpenAnime: (anime: Anime) => void }) {
  return (
    <section className="recently-added">
      <SectionHeading>Recently Added</SectionHeading>
      <div className="mini-poster-grid">
        {recentlyAdded.slice(0, 9).map((image, index) => {
          const anime = getAnime(image);
          const inner = <img src={animeImage(image)} alt={anime?.title || `Recently added anime ${index + 1}`} loading="lazy" />;
          return anime ? (
            <button type="button" key={image} onClick={() => onOpenAnime(anime)} title={anime.title}>{inner}<span><Play size={13} fill="currentColor" /></span></button>
          ) : <div key={image}>{inner}</div>;
        })}
      </div>
    </section>
  );
}

function RecentlyUpdated({ selectedGenre, onClearGenre, onOpenAnime, onToggleList, watchlist }: {
  selectedGenre: string;
  onClearGenre: () => void;
  onOpenAnime: (anime: Anime) => void;
  onToggleList: (id: string) => void;
  watchlist: string[];
}) {
  const filtered = selectedGenre === "All" ? recentlyUpdated : recentlyUpdated.filter((anime) => anime.genres.includes(selectedGenre));
  return (
    <section id="recently-updated" className="recently-updated">
      <SectionHeading action={selectedGenre !== "All" ? (
        <button className="filter-chip" type="button" onClick={onClearGenre}><ListFilter size={14} /> {selectedGenre} <X size={13} /></button>
      ) : undefined}>Recently Updated</SectionHeading>
      {filtered.length ? (
        <div className="updated-grid">
          {filtered.map((anime) => (
            <UpdatedCard key={anime.id} anime={anime} onOpen={() => onOpenAnime(anime)} onToggleList={onToggleList} saved={watchlist.includes(anime.id)} />
          ))}
        </div>
      ) : (
        <div className="empty-filter">
          <ListFilter size={32} />
          <h3>No recent titles in {selectedGenre}</h3>
          <p>Explore the complete recently updated collection instead.</p>
          <button className="gradient-button" type="button" onClick={onClearGenre}>Clear filter</button>
        </div>
      )}
    </section>
  );
}

function AllTimeCollections({ onOpenAnime }: { onOpenAnime: (anime: Anime) => void }) {
  return (
    <section className="section all-time-section" id="all-time">
      <div className="collections-grid">
        {Object.entries(collections).map(([title, images]) => (
          <div className="collection" key={title}>
            <SectionHeading>{title}</SectionHeading>
            <div className="collection-posters">
              {images.map((image, index) => {
                const anime = getAnime(image);
                const imageElement = <img src={animeImage(image)} alt={anime?.title || `${title} selection ${index + 1}`} loading="lazy" />;
                return anime ? (
                  <button type="button" key={`${title}-${image}-${index}`} onClick={() => onOpenAnime(anime)} title={anime.title}>{imageElement}<span>{anime.title}</span></button>
                ) : <div key={`${title}-${image}-${index}`} title={`${title} selection ${index + 1}`}>{imageElement}</div>;
              })}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function Schedule({ reminders, onToggleReminder }: { reminders: string[]; onToggleReminder: (key: string) => void }) {
  const [selectedDay, setSelectedDay] = useState(0);
  const [now, setNow] = useState(new Date());
  const days = useMemo(() => Array.from({ length: 15 }, (_, index) => {
    const date = new Date();
    date.setDate(date.getDate() + index);
    return date;
  }), []);

  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  const dayShows = scheduleShows.map((_, index) => scheduleShows[(index + selectedDay) % scheduleShows.length]);

  return (
    <section className="section schedule-section" id="schedule">
      <div className="schedule-heading-row">
        <SectionHeading>Estimated Schedule</SectionHeading>
        <div className="live-clock">
          <span><CalendarDays size={16} /> {now.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</span>
          <strong><Radio size={15} /> {now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}</strong>
        </div>
      </div>
      <div className="schedule-days" role="tablist" aria-label="Schedule date">
        {days.map((day, index) => (
          <button key={day.toISOString()} type="button" role="tab" aria-selected={selectedDay === index} className={selectedDay === index ? "active" : ""} onClick={() => setSelectedDay(index)}>
            <strong>{index === 0 ? "Today" : day.toLocaleDateString("en-US", { weekday: "short" })}</strong>
            <span>{day.toLocaleDateString("en-US", { month: "short", day: "numeric" })}</span>
          </button>
        ))}
      </div>
      <div className="schedule-list" key={selectedDay}>
        {dayShows.slice(0, 4).map((show, index) => {
          const anime = getAnime(show.animeId)!;
          const reminderKey = `${days[selectedDay].toDateString()}-${show.animeId}`;
          const saved = reminders.includes(reminderKey);
          return (
            <article className="schedule-item" key={`${reminderKey}-${index}`}>
              <img src={animeImage(anime.image)} alt="" loading="lazy" />
              <div className="schedule-time"><Clock3 size={15} /><strong>{show.time}</strong><span>JST</span></div>
              <div className="schedule-name"><strong>{anime.title}</strong><span>Episode {((show.episode + selectedDay) % 12) + 1} · Subtitled</span></div>
              <button type="button" className={saved ? "reminder-active" : ""} onClick={() => onToggleReminder(reminderKey)} aria-label={`${saved ? "Remove" : "Set"} reminder for ${anime.title}`}>
                {saved ? <BellRing size={17} /> : <Bell size={17} />}<span>{saved ? "Reminder set" : "Remind me"}</span>
              </button>
            </article>
          );
        })}
      </div>
    </section>
  );
}

function useCountdown() {
  const target = useMemo(() => {
    try {
      const saved = localStorage.getItem("kokomi-release-target");
      if (saved) {
        const savedDate = new Date(saved);
        if (!Number.isNaN(savedDate.getTime()) && savedDate.getTime() > Date.now()) return savedDate;
      }
      const date = new Date();
      date.setDate(date.getDate() + 24);
      date.setHours(18, 0, 0, 0);
      localStorage.setItem("kokomi-release-target", date.toISOString());
      return date;
    } catch {
      const date = new Date();
      date.setDate(date.getDate() + 24);
      date.setHours(18, 0, 0, 0);
      return date;
    }
  }, []);
  const calculate = () => Math.max(0, target.getTime() - Date.now());
  const [remaining, setRemaining] = useState(calculate);
  useEffect(() => {
    const timer = window.setInterval(() => setRemaining(calculate()), 1000);
    return () => window.clearInterval(timer);
  }, [target]);
  const totalSeconds = Math.floor(remaining / 1000);
  return {
    days: Math.floor(totalSeconds / 86400),
    hours: Math.floor((totalSeconds % 86400) / 3600),
    minutes: Math.floor((totalSeconds % 3600) / 60),
    seconds: totalSeconds % 60,
  };
}

function ComingOut({ onGenre, reminder, onReminder }: { onGenre: (genre: string) => void; reminder: boolean; onReminder: () => void }) {
  const countdown = useCountdown();
  const anime = getAnime("one-piece-fish-man-island")!;
  return (
    <section className="coming-section" id="coming-soon">
      <div className="coming-backdrop"><img src={animeImage(anime.image)} alt="" /></div>
      <div className="coming-copy">
        <span className="coming-kicker">One Piece</span>
        <h2>One Piece Log: Fish-Man Island Saga</h2>
        <p>Embark on a voyage of a lifetime with One Piece. The epic anime series created by renowned mangaka Eiichiro Oda is a global phenomenon, captivating the hearts of fans across generations throughout its 25-year span. This thrilling high seas adventure is filled with unwavering friendship, epic battles for freedom, and the relentless pursuit of dreams. Join Monkey D. Luffy and his lovable pirate crew as they discover the true meaning of power and justice in this great pirate era.</p>
        <ul className="coming-details">
          <li><Mic2 size={17} /><span><strong>Audio:</strong> Japanese, English</span></li>
          <li><Captions size={17} /><span><strong>Subtitles:</strong> English, Bahasa Indonesia, Tiếng Việt, ไทย</span></li>
          <li><Sparkles size={17} /><span><strong>Genres:</strong> {anime.genres.map((genre, index) => <span key={genre}><button type="button" onClick={() => onGenre(genre)}>{genre}</button>{index < anime.genres.length - 1 ? ", " : ""}</span>)}</span></li>
        </ul>
        <div className="countdown-label">— Coming Out in —</div>
        <div className="countdown" aria-label="Release countdown">
          {Object.entries(countdown).map(([unit, value]) => (
            <div key={unit}><strong>{String(value).padStart(2, "0")}</strong><span>{unit}</span></div>
          ))}
        </div>
        <button className={`glass-button coming-reminder ${reminder ? "saved" : ""}`} type="button" onClick={onReminder}>
          {reminder ? <BellRing size={17} /> : <Bell size={17} />}{reminder ? "Release reminder set" : "Remind me on release"}
        </button>
      </div>
      <div className="coming-poster-wrap">
        <div className="coming-poster">
          <img src={animeImage(anime.image)} alt={anime.title} loading="lazy" />
          <span>New special edition</span>
        </div>
      </div>
    </section>
  );
}

const appBenefits = [
  "Free HD Movies App for Android with Chromecast support.",
  "Multiple languages of Subtitles.",
  "Absolutely No Ads.",
  "Fast streaming speed than on the website.",
  "All streaming issues will be fixed within 24 hours.",
  "Daily update on both Movies and Shows.",
];

function DownloadApp() {
  const [showNote, setShowNote] = useState(false);
  const columns = [[1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]];
  return (
    <section className="download-section" id="download-app">
      <div className="download-copy">
        <span className="app-icon"><Smartphone size={25} /></span>
        <h2>Best Anime Android App</h2>
        <h3>Watch and Download Anime on your Android device for Free</h3>
        <ul>{appBenefits.map((benefit) => <li key={benefit}><CheckCircle2 size={17} />{benefit}</li>)}</ul>
        <button className="gradient-button" type="button" onClick={() => setShowNote((visible) => !visible)} aria-expanded={showNote}>
          <Download size={18} /> Download for android
        </button>
        {showNote && <p className="app-download-note"><ShieldCheck size={17} /> This template preview does not distribute an APK. The interface is ready to connect to your production app download.</p>}
      </div>
      <div className="app-poster-scene" aria-label="Anime app preview">
        <div className="app-glow" />
        <div className="app-poster-wall">
          {columns.map((column, columnIndex) => (
            <div className={`app-poster-column column-${columnIndex + 1}`} key={columnIndex}>
              {[...column, ...column].map((image, index) => <img key={`${image}-${index}`} src={appImage(image)} alt="" loading="lazy" />)}
            </div>
          ))}
        </div>
        <div className="app-playing-card">
          <span><Play size={16} fill="currentColor" /></span>
          <div><strong>Continue Watching</strong><small>HD · Multiple subtitles</small></div>
          <Zap size={17} />
        </div>
      </div>
    </section>
  );
}

function Trailers() {
  return (
    <section className="section trailers-section" id="trailers">
      <SectionHeading action={<a className="view-all-link" href="https://www.youtube.com/results?search_query=upcoming+anime+trailers" target="_blank" rel="noreferrer">View all <ArrowRight size={15} /></a>}>Upcoming Anime Trailers</SectionHeading>
      <div className="trailer-grid">
        {trailerItems.map((item, index) => {
          const anime = getAnime(item.animeId)!;
          return (
            <a className={`trailer-card ${index === 0 ? "trailer-feature" : ""}`} key={item.animeId} href={trailerSearch(anime.title)} target="_blank" rel="noreferrer">
              <img src={animeImage(anime.image)} alt={anime.title} loading="lazy" />
              <span className="trailer-shade" />
              <span className="trailer-play"><Play size={index === 0 ? 25 : 18} fill="currentColor" /></span>
              <span className="trailer-caption">
                <small>{item.label}</small>
                <strong>{anime.title}</strong>
                <span>By Kokomi <i /> {item.date}</span>
              </span>
            </a>
          );
        })}
      </div>
    </section>
  );
}

function Footer() {
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = usePersistentState("kokomi-newsletter", false);
  const [error, setError] = useState("");
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!/^\S+@\S+\.\S+$/.test(email)) {
      setError("Please enter a valid email address.");
      return;
    }
    setError("");
    setSubscribed(true);
  };
  return (
    <footer className="site-footer">
      <div className="footer-newsletter" id="newsletter">
        <div><Mail size={25} /><span><strong>Never miss a new episode</strong><small>Weekly anime releases, curated for you.</small></span></div>
        {subscribed ? (
          <div className="newsletter-success"><CheckCircle2 size={20} /><span><strong>You're on the list!</strong><small>Your preference is saved on this device.</small></span><button type="button" onClick={() => { setSubscribed(false); setEmail(""); }}>Use another email</button></div>
        ) : (
          <form onSubmit={submit} noValidate>
            <div><input type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="Your email address" aria-label="Email address" /><button type="submit">Subscribe <Send size={16} /></button></div>
            {error && <span className="form-error">{error}</span>}
          </form>
        )}
      </div>
      <div className="footer-main">
        <div className="footer-about">
          <Logo />
          <p>Your portal to unforgettable anime stories. Discover new worlds, follow weekly episodes and keep every favorite in one place.</p>
          <div className="social-links">
            <a href="https://www.facebook.com" target="_blank" rel="noreferrer" aria-label="Facebook"><Globe2 size={18} /></a>
            <a href="https://www.twitter.com" target="_blank" rel="noreferrer" aria-label="Twitter"><MessageCircle size={18} /></a>
            <a href="https://www.instagram.com" target="_blank" rel="noreferrer" aria-label="Instagram"><Camera size={18} /></a>
            <a href="https://www.youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube"><Play size={18} /></a>
          </div>
        </div>
        <div className="footer-links"><h3>Browse</h3><a href="#trending">Trending Now</a><a href="#recently-updated">Recently Updated</a><a href="#all-time">Most Popular</a><a href="#schedule">Release Schedule</a></div>
        <div className="footer-links"><h3>Explore</h3><a href="#coming-soon">Coming Soon</a><a href="#trailers">Anime Trailers</a><a href="#download-app">Android App</a><a href="#community">Community</a></div>
        <div className="footer-links"><h3>Genres</h3><a href="#recently-updated">Action</a><a href="#recently-updated">Adventure</a><a href="#recently-updated">Fantasy</a><a href="#recently-updated">Romance</a></div>
      </div>
      <div className="footer-bottom"><span>Copyright © 2025 <strong>Kokomi</strong>. All Rights Reserved.</span><div><a href="#/legal/privacy">Privacy Policy</a><a href="#/legal/terms">Terms of Service</a><a href="#/legal/dmca">DMCA</a></div></div>
      <span id="footer-legal" className="legal-note">Kokomi is an entertainment website template. Anime titles and artwork belong to their respective owners.</span>
    </footer>
  );
}

function WatchlistDrawer({ open, onClose, ids, onToggle, onOpenAnime }: { open: boolean; onClose: () => void; ids: string[]; onToggle: (id: string) => void; onOpenAnime: (anime: Anime) => void }) {
  useEffect(() => {
    document.body.classList.toggle("no-scroll", open);
    return () => document.body.classList.remove("no-scroll");
  }, [open]);
  const items = ids.map((id) => getAnime(id)).filter(Boolean) as Anime[];
  return (
    <div className={`watchlist-drawer ${open ? "open" : ""}`} aria-hidden={!open}>
      <button className="overlay-dismiss" type="button" aria-label="Close my list" onClick={onClose} />
      <aside role="dialog" aria-modal="true" aria-label="My anime list">
        <div className="drawer-head"><div><Bookmark size={20} /><h2>My List</h2><span>{items.length}</span></div><IconButton label="Close my list" onClick={onClose}><X size={21} /></IconButton></div>
        <p className="drawer-intro">Your saved anime, ready whenever you are.</p>
        <div className="watchlist-items">
          {items.length === 0 && <div className="empty-list"><Bookmark size={38} /><h3>Your list is waiting</h3><p>Use the + button on any anime to save it here. Your list stays on this device.</p><button className="gradient-button" type="button" onClick={onClose}>Explore anime</button></div>}
          {items.map((anime) => (
            <article key={anime.id}>
              <button type="button" className="watchlist-item-main" onClick={() => { onOpenAnime(anime); onClose(); }}>
                <img src={animeImage(anime.image)} alt="" />
                <span><strong>{anime.title}</strong><small>{anime.year} · {anime.episodes} Episodes</small><i><Star size={11} fill="currentColor" /> {anime.rating}</i></span>
              </button>
              <button type="button" className="remove-list-item" onClick={() => onToggle(anime.id)} aria-label={`Remove ${anime.title}`}><X size={16} /></button>
            </article>
          ))}
        </div>
      </aside>
    </div>
  );
}

function DetailPage({ anime, watchlist, onToggleList }: { anime: Anime; watchlist: string[]; onToggleList: (id: string) => void }) {
  const [episode, setEpisode] = useState(1);
  const sourceEpisodes = useMemo(() => getSourceEpisodes(anime), [anime]);
  const [watched, setWatched] = usePersistentState<string[]>(`kokomi-watched-${anime.id}`, []);
  const saved = watchlist.includes(anime.id);
  const episodeKey = String(episode);
  const episodeWatched = watched.includes(episodeKey);
  const watchedCount = sourceEpisodes.filter((item) => watched.includes(String(item.number))).length;

  useEffect(() => {
    setEpisode(1);
    window.scrollTo({ top: 0, behavior: "instant" });
  }, [anime.id]);

  const toggleWatched = () => setWatched((current) => current.includes(episodeKey) ? current.filter((item) => item !== episodeKey) : [...current, episodeKey]);

  return (
    <main className="detail-page watch-page">
      <header className="watch-heading">
        <div className="watch-breadcrumb"><a href="#home">Home</a><ChevronRight size={13} /><span>Watch</span></div>
        <div className="watch-heading-row">
          <img src={animeImage(anime.image)} alt="" />
          <div><span className="watch-heading-kicker">Now watching</span><h1>{anime.title}</h1><p>Season 1 <span>/</span> Episode {episode}</p></div>
          <button className={`glass-button watch-save ${saved ? "saved" : ""}`} type="button" onClick={() => onToggleList(anime.id)} aria-label={saved ? "Remove selected anime from my list" : "Add selected anime to my list"}>{saved ? <Check size={17} /> : <Bookmark size={17} />}<span>{saved ? "In my list" : "My list"}</span></button>
        </div>
      </header>

      <section className="detail-watch-section" id="episodes">
        <StreamingPlayer anime={anime} episode={episode} episodes={sourceEpisodes} onEpisodeChange={setEpisode} />
        <div className="episode-browser">
          <div className="episode-browser-head"><div><Tv size={19} /><span><strong>Episodes</strong><small>Season 1 · {sourceEpisodes.length} available episodes</small></span></div><span>{watchedCount}/{sourceEpisodes.length} watched</span></div>
          <div className="episode-progress"><span style={{ width: `${sourceEpisodes.length ? Math.min(100, (watchedCount / sourceEpisodes.length) * 100) : 0}%` }} /></div>
          <div className="episode-list">
            {sourceEpisodes.map(({ number }) => (
              <button type="button" key={number} aria-label={`Select episode ${number}`} aria-pressed={episode === number} className={`${episode === number ? "active" : ""} ${watched.includes(String(number)) ? "watched" : ""}`} onClick={() => setEpisode(number)}>
                <span>{watched.includes(String(number)) ? <Check size={14} /> : <Play size={13} fill="currentColor" />}</span><strong>Episode {number}</strong><small>{anime.duration}m</small>
              </button>
            ))}
            {!sourceEpisodes.length && <div className="source-no-episodes"><Tv size={28} /><strong>No video available yet</strong><p>Only episodes of the selected anime will appear here. Other titles will not be substituted.</p></div>}
          </div>
          <button type="button" disabled={!sourceEpisodes.length} className={`mark-watched ${episodeWatched ? "watched" : ""}`} onClick={toggleWatched}>{episodeWatched ? <CheckCircle2 size={17} /> : <Eye size={17} />}{episodeWatched ? "Marked as watched" : "Mark episode as watched"}</button>
        </div>
      </section>

    </main>
  );
}

function HomePage({ selectedGenre, onSelectGenre, onOpenAnime, onToggleList, watchlist, reminders, onToggleReminder, releaseReminder, onReleaseReminder }: {
  selectedGenre: string;
  onSelectGenre: (genre: string) => void;
  onOpenAnime: (anime: Anime) => void;
  onToggleList: (id: string) => void;
  watchlist: string[];
  reminders: string[];
  onToggleReminder: (key: string) => void;
  releaseReminder: boolean;
  onReleaseReminder: () => void;
}) {
  return (
    <main>
      <Hero onOpenAnime={onOpenAnime} onToggleList={onToggleList} watchlist={watchlist} />
      <Genres selected={selectedGenre} onSelect={onSelectGenre} />
      <Trending onOpenAnime={onOpenAnime} onToggleList={onToggleList} watchlist={watchlist} />
      <div className="home-content-grid">
        <RecentlyUpdated selectedGenre={selectedGenre} onClearGenre={() => onSelectGenre("All")} onOpenAnime={onOpenAnime} onToggleList={onToggleList} watchlist={watchlist} />
        <aside className="home-sidebar"><TopTen onOpenAnime={onOpenAnime} /><RecentlyAdded onOpenAnime={onOpenAnime} /></aside>
      </div>
      <AllTimeCollections onOpenAnime={onOpenAnime} />
      <Schedule reminders={reminders} onToggleReminder={onToggleReminder} />
      <ComingOut onGenre={onSelectGenre} reminder={releaseReminder} onReminder={onReleaseReminder} />
      <DownloadApp />
      <Trailers />
    </main>
  );
}

export default function App() {
  const [hash, setHash] = useState(window.location.hash || "#home");
  const [watchlist, setWatchlist] = usePersistentState<string[]>("kokomi-watchlist", []);
  const [reminders, setReminders] = usePersistentState<string[]>("kokomi-reminders", []);
  const [releaseReminder, setReleaseReminder] = usePersistentState("kokomi-release-reminder", false);
  const [selectedGenre, setSelectedGenre] = useState("All");
  const [watchlistOpen, setWatchlistOpen] = useState(false);
  const [toast, setToast] = useState("");
  const [showTop, setShowTop] = useState(false);

  useEffect(() => {
    const onHashChange = () => setHash(window.location.hash || "#home");
    const onScroll = () => setShowTop(window.scrollY > 650);
    window.addEventListener("hashchange", onHashChange);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => { window.removeEventListener("hashchange", onHashChange); window.removeEventListener("scroll", onScroll); };
  }, []);

  useEffect(() => {
    if (hash.startsWith("#/anime/") || hash.startsWith("#/legal/")) {
      window.scrollTo({ top: 0, behavior: "instant" });
      return;
    }
    const targetId = hash.replace(/^#\/?/, "") || "home";
    const frame = window.requestAnimationFrame(() => {
      document.getElementById(targetId)?.scrollIntoView({ block: "start" });
    });
    return () => window.cancelAnimationFrame(frame);
  }, [hash]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(""), 2600);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const openAnime = (anime: Anime) => {
    window.location.hash = `/anime/${anime.id}`;
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const toggleList = (id: string) => {
    const exists = watchlist.includes(id);
    setWatchlist((current) => exists ? current.filter((item) => item !== id) : [...current, id]);
    setToast(exists ? "Removed from My List" : "Added to My List");
  };

  const toggleReminder = (key: string) => {
    const exists = reminders.includes(key);
    setReminders((current) => exists ? current.filter((item) => item !== key) : [...current, key]);
    setToast(exists ? "Episode reminder removed" : "Episode reminder saved");
  };

  const selectGenre = (genre: string) => {
    setSelectedGenre(genre);
    if (window.location.hash.startsWith("#/anime/")) window.location.hash = "recently-updated";
    window.setTimeout(() => document.getElementById("recently-updated")?.scrollIntoView({ behavior: "smooth" }), 40);
  };

  const detailAnime = hash.startsWith("#/anime/") ? getAnime(hash.replace("#/anime/", "")) : undefined;
  const legalPath = hash.startsWith("#/legal/") ? hash.replace("#/legal/", "") : "";
  const legalTopic = (["privacy", "terms", "dmca"] as const).includes(legalPath as LegalTopic)
    ? (legalPath as LegalTopic)
    : undefined;

  useEffect(() => {
    document.title = detailAnime
      ? `${detailAnime.title} — Kokomi`
      : legalTopic
        ? `${legalTopic === "dmca" ? "Copyright & DMCA" : legalTopic === "terms" ? "Terms of Service" : "Privacy Policy"} — Kokomi`
        : "Kokomi — Online Anime & Anime Series";
  }, [detailAnime, legalTopic]);

  return (
    <div className="site-shell">
      <Header watchlistCount={watchlist.length} onOpenWatchlist={() => setWatchlistOpen(true)} onOpenAnime={openAnime} onSelectGenre={selectGenre} />
      {detailAnime ? (
        <DetailPage key={detailAnime.id} anime={detailAnime} watchlist={watchlist} onToggleList={toggleList} />
      ) : legalTopic ? (
        <LegalPage topic={legalTopic} />
      ) : (
        <HomePage selectedGenre={selectedGenre} onSelectGenre={selectGenre} onOpenAnime={openAnime} onToggleList={toggleList} watchlist={watchlist} reminders={reminders} onToggleReminder={toggleReminder} releaseReminder={releaseReminder} onReleaseReminder={() => { setReleaseReminder(!releaseReminder); setToast(releaseReminder ? "Release reminder removed" : "Release reminder saved"); }} />
      )}
      <Footer />
      <WatchlistDrawer open={watchlistOpen} onClose={() => setWatchlistOpen(false)} ids={watchlist} onToggle={toggleList} onOpenAnime={openAnime} />
      <button id="upToTopBtn" className={showTop ? "active" : ""} type="button" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} aria-label="Back to top"><ArrowUp size={23} /></button>
      <div className={`toast ${toast ? "show" : ""}`} role="status"><CheckCircle2 size={18} />{toast}</div>
    </div>
  );
}
