import {
  ChevronLeft,
  ChevronRight,
  Info,
  LoaderCircle,
  Maximize,
  Minimize,
  Play,
  RotateCw,
  Square,
  Tv,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { animeImage, type Anime } from "../data";
import { getVideoEmbedUrl, serverPreferenceKey, type SourceEpisode } from "./providers";
import "./streaming.css";

type StreamingPlayerProps = {
  anime: Anime;
  episode: number;
  episodes: SourceEpisode[];
  onEpisodeChange: (episode: number) => void;
};

export default function StreamingPlayer({ anime, episode, episodes, onEpisodeChange }: StreamingPlayerProps) {
  const [opened, setOpened] = useState(false);
  const [loadPhase, setLoadPhase] = useState<"loading" | "opened" | "slow">("loading");
  const [revision, setRevision] = useState(0);
  const [serverId, setServerId] = useState(() => {
    try {
      const saved: unknown = JSON.parse(localStorage.getItem(serverPreferenceKey) ?? "null");
      return typeof saved === "string" && /^server-\d+$/.test(saved) ? saved : "server-1";
    } catch { return "server-1"; }
  });
  const [fullscreen, setFullscreen] = useState(false);
  const [fullscreenError, setFullscreenError] = useState("");
  const frameContainer = useRef<HTMLDivElement>(null);
  const episodeIndex = episodes.findIndex((item) => item.number === episode);
  const players = episodes[episodeIndex]?.players ?? [];
  const selectedPlayer = players.find((player) => player.id === serverId) ?? players[0];
  const frameUrl = selectedPlayer ? getVideoEmbedUrl(selectedPlayer.embedUrl) : undefined;

  useEffect(() => {
    setLoadPhase("loading");
  }, [episode, selectedPlayer?.id, revision]);

  useEffect(() => {
    try {
      localStorage.setItem(serverPreferenceKey, JSON.stringify(serverId));
    } catch { /* Playback works without persistent storage. */ }
  }, [serverId]);

  useEffect(() => {
    if (!opened || !frameUrl || loadPhase !== "loading") return;
    // Cross-origin load events do not prove playback; keep in-site recovery controls available.
    const timer = window.setTimeout(() => setLoadPhase("slow"), 16000);
    return () => window.clearTimeout(timer);
  }, [opened, frameUrl, loadPhase, revision]);

  useEffect(() => {
    const update = () => setFullscreen(document.fullscreenElement === frameContainer.current);
    document.addEventListener("fullscreenchange", update);
    return () => document.removeEventListener("fullscreenchange", update);
  }, []);

  const toggleFullscreen = async () => {
    setFullscreenError("");
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else if (frameContainer.current?.requestFullscreen) await frameContainer.current.requestFullscreen();
      else setFullscreenError("Use the video's fullscreen control in this browser.");
    } catch {
      setFullscreenError("Fullscreen could not start. The video remains available here.");
    }
  };

  const reload = () => {
    setLoadPhase("loading");
    setRevision((current) => current + 1);
  };

  return (
    <div className="streaming-player" aria-label={`${anime.title} video player`}>
      <div className="source-selector">
        <span><Tv size={16} /> Watch here</span>
        {players.length > 0 ? (
          <div role="group" aria-label="Select video server">
            {players.map((player) => (
              <button
                type="button"
                key={player.id}
                className={selectedPlayer?.id === player.id ? "active" : ""}
                aria-pressed={selectedPlayer?.id === player.id}
                onClick={() => {
                  if (selectedPlayer?.id !== player.id) setLoadPhase("loading");
                  setServerId(player.id);
                }}
              >{player.label}</button>
            ))}
          </div>
        ) : <span className="source-unavailable-label">No video source</span>}
      </div>

      <div className="source-player-container" ref={frameContainer}>
        <div className="source-player-screen">
          {opened && frameUrl ? (
            <>
              <iframe
                key={`${episode}-${selectedPlayer.id}-${revision}`}
                className="animesalt-frame"
                src={frameUrl}
                title={`${anime.title} - Season 1 Episode ${episode}`}
                sandbox="allow-scripts allow-same-origin allow-presentation"
                allow="autoplay *; encrypted-media *; fullscreen *; picture-in-picture *"
                referrerPolicy="strict-origin-when-cross-origin"
                allowFullScreen
                onLoad={() => setLoadPhase("opened")}
              />
              {loadPhase === "loading" && (
                <div className="source-loading" role="status">
                  <LoaderCircle size={27} />
                  <strong>Loading episode {episode}</strong>
                  <span>Your video will play here.</span>
                </div>
              )}
            </>
          ) : (
            <>
              <img className="source-preview-image" src={animeImage(anime.image)} alt="" />
              <div className="source-preview-shade" />
              <div className="source-preview-copy">
                <span className="source-preview-kicker">{frameUrl ? "SEASON 1" : "VIDEO SOURCE UNAVAILABLE"}</span>
                <h2>{frameUrl ? `Episode ${episode}` : "Episode unavailable"}</h2>
                {frameUrl ? (
                  <>
                    <button className="gradient-button" type="button" onClick={() => { setLoadPhase("loading"); setOpened(true); }}>
                      <Play size={18} fill="currentColor" /> Play episode
                    </button>
                    <small>Play inside Kokomi. No external page or anime details.</small>
                  </>
                ) : <p>A verified player is not available for this exact title. No different anime will be shown.</p>}
              </div>
            </>
          )}
        </div>

        <div className="source-player-toolbar">
          <div className="source-now-selected"><Tv size={15} /><span>{episodeIndex >= 0 ? `S1 E${episode} / ${selectedPlayer?.label}` : "Selected title / Unavailable"}</span></div>
          <div className="source-toolbar-actions">
            {opened && frameUrl && (
              <>
                <button type="button" onClick={reload} aria-label="Reload video" title="Reload video"><RotateCw size={16} /></button>
                <button type="button" onClick={() => setOpened(false)} aria-label="Stop video" title="Stop video"><Square size={14} /></button>
              </>
            )}
            <button type="button" onClick={toggleFullscreen} aria-label={fullscreen ? "Exit player fullscreen" : "Player fullscreen"} title={fullscreen ? "Exit fullscreen" : "Fullscreen"}>
              {fullscreen ? <Minimize size={17} /> : <Maximize size={17} />}
            </button>
          </div>
        </div>
        {fullscreenError && <p className="source-fullscreen-error" role="status">{fullscreenError}</p>}
      </div>

      {loadPhase === "slow" && opened && <div className="source-slow-notice" role="status"><Info size={16} /><span>The video is taking longer than expected. Retry or choose the other server above. You will stay on this page.</span><button type="button" onClick={reload}>Retry</button></div>}

      <div className="source-episode-navigation">
        <button type="button" disabled={episodeIndex <= 0} onClick={() => onEpisodeChange(episodes[episodeIndex - 1].number)}><ChevronLeft size={17} /><span>Previous episode</span></button>
        <span>{episodeIndex >= 0 ? `Season 1 / Episode ${episode}` : "No episode available"}</span>
        <button type="button" disabled={episodeIndex < 0 || episodeIndex >= episodes.length - 1} onClick={() => onEpisodeChange(episodes[episodeIndex + 1].number)}><span>Next episode</span><ChevronRight size={17} /></button>
      </div>

      <div className="source-explanation">
        <Info size={15} />
        <p>Video not starting? Reload or switch servers here. Audio and quality settings are inside the video controls. Video source: AnimeSalt.</p>
      </div>
    </div>
  );
}