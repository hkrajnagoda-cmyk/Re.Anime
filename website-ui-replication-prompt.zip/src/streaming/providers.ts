import type { Anime } from "../data";
import animeSaltCatalog from "./animesalt-catalog.json";
import animeSaltPlayers from "./animesalt-players.json";

export type VideoPlayer = {
  id: string;
  label: string;
  embedUrl: string;
};

export type SourceEpisode = {
  number: number;
  pageUrl: string;
  players: VideoPlayer[];
};

type CatalogTitle = {
  seriesUrl: string;
  season: number;
  seasonCount: number;
  episodes: Array<{ number: number; pageUrl: string }>;
};

export const serverPreferenceKey = "kokomi-video-server";
export const animeSaltOrigin = animeSaltCatalog.origin;
const animeSaltTitles: Record<string, CatalogTitle> = animeSaltCatalog.titles;
const episodePlayers: Record<string, { checkedAt: string; players: VideoPlayer[] }> = animeSaltPlayers.episodes;

function getAnimeSaltTitle(animeId: string): CatalogTitle | undefined {
  return Object.prototype.hasOwnProperty.call(animeSaltTitles, animeId) ? animeSaltTitles[animeId] : undefined;
}

export function getSourceEpisodes(anime: Anime): SourceEpisode[] {
  return (getAnimeSaltTitle(anime.id)?.episodes ?? [])
    .map((episode) => ({ ...episode, players: getEpisodePlayers(episode.pageUrl) }))
    .filter((episode) => episode.players.length > 0);
}

export function getEpisodePlayers(pageUrl: string): VideoPlayer[] {
  const record = Object.prototype.hasOwnProperty.call(episodePlayers, pageUrl) ? episodePlayers[pageUrl] : undefined;
  return (record?.players ?? []).filter((player) => getVideoEmbedUrl(player.embedUrl) !== undefined);
}

export function getVideoEmbedUrl(value: string): string | undefined {
  try {
    const url = new URL(value);
    if (url.protocol !== "https:" || url.username || url.password || url.hash) return undefined;
    if (url.origin === "https://ravok.buzz" && /^\/video\/[a-f\d]{32}\/?$/i.test(url.pathname) && !url.search) return url.href;
    if (url.origin === animeSaltOrigin && url.pathname === "/wp-content/themes/torofilm/public/plyr/player.php" && url.searchParams.get("data")) return url.href;
    return undefined;
  } catch {
    return undefined;
  }
}