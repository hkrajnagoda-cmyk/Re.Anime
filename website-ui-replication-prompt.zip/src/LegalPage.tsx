import { ArrowLeft, ChevronRight, ShieldCheck } from "lucide-react";

export type LegalTopic = "privacy" | "terms" | "dmca";

const legalContent: Record<LegalTopic, { title: string; intro: string; sections: Array<{ title: string; body: string }> }> = {
  privacy: {
    title: "Privacy Policy",
    intro: "This policy describes exactly how the Kokomi website preview handles preferences and external services.",
    sections: [
      { title: "Local preferences", body: "Your anime list, episode progress, preferred video server, reminders, release countdown and newsletter preference are stored only in your browser's local storage. This preview does not send those preferences to a Kokomi account or server." },
      { title: "Search and navigation", body: "Anime search runs entirely within the catalog included in this website. Search terms are not transmitted to a separate analytics service by this implementation." },
      { title: "External media and providers", body: "Poster artwork and fonts are loaded from external providers. Clicking Play episode loads only a third-party video player inside Kokomi, not the provider's full anime-details page. Video providers may use their own cookies, ads and technical logging, and their privacy practices apply. Player frames are not permitted to open popups or navigate the top-level site. Kokomi does not receive your provider credentials or the video's viewing history. Trailer and social links elsewhere on the site can open external websites." },
      { title: "Newsletter preview", body: "The newsletter form validates your email and remembers that you subscribed on this device. It does not submit your address to a mailing service in this template preview. A production deployment should connect the form to a disclosed consent-based email provider." },
      { title: "Clearing your data", body: "You can remove individual anime and reminders through the interface. To clear every saved preference, clear this site's local storage in your browser settings." },
    ],
  },
  terms: {
    title: "Terms of Service",
    intro: "These terms apply to use of the Kokomi entertainment website template preview.",
    sections: [
      { title: "Template preview", body: "Kokomi provides a browsing and discovery interface. Features that require a production service—such as user accounts, mailing delivery or an Android package—are identified as preview functionality rather than presented as completed external services." },
      { title: "Streaming sources", body: "Kokomi embeds the video-only iframe URLs published in AnimeSalt's native episode player. This is not a direct media API or a representation of a licensing partnership. Full provider pages and external streaming-search buttons are not used in the watch interface. Kokomi does not extract or proxy media files. Audio, subtitles, quality, ads, playback and regional availability remain under the video's provider's control. A frame load event alone does not confirm successful playback." },
      { title: "Acceptable use", body: "Do not attempt to disrupt the website, misuse external media URLs, misrepresent template content as your own licensed catalog, or use the interface for unlawful activity." },
      { title: "Catalog information", body: "Episode and video-player URLs are a dated snapshot of public first-season entries and may change. Only exact matching title and episode players are used. An unavailable source is shown as unavailable rather than replaced with another anime or a provider-details page. Other catalog, schedule and release information in this template is illustrative." },
      { title: "Production deployment", body: "A site owner adapting this template should replace preview policies with their own business details, publish accurate contact channels and review the terms applicable in their jurisdiction." },
    ],
  },
  dmca: {
    title: "Copyright & DMCA",
    intro: "Kokomi respects the rights of anime creators, publishers, studios and artwork owners.",
    sections: [
      { title: "Rights and attribution", body: "Anime titles, character names and artwork remain the property of their respective owners. Their presence in this entertainment template does not transfer ownership or distribution rights." },
      { title: "External assets", body: "The preview references the original demonstration artwork URLs rather than claiming to host a licensed streaming catalog. Production site owners must confirm that they have appropriate rights for every asset they publish." },
      { title: "Copyright review information", body: "A complete copyright review request should identify the protected work, provide the exact page or asset URL, explain the reporter's authority to act, include good-faith and accuracy statements, and supply a valid reply channel." },
      { title: "Production contact requirement", body: "This standalone preview does not invent a copyright agent or email address. Before public deployment, the site operator must add a monitored legal contact and a repeatable review and counter-notice process." },
      { title: "Removal of preview material", body: "Where a valid rights concern is identified, the responsible site operator should promptly restrict the disputed material while reviewing the request and documenting any restoration decision." },
    ],
  },
};

export default function LegalPage({ topic }: { topic: LegalTopic }) {
  const content = legalContent[topic];
  return (
    <main className="legal-page">
      <div className="legal-hero">
        <a href="#home"><ArrowLeft size={16} /> Back to Kokomi</a>
        <span><ShieldCheck size={19} /> Kokomi information</span>
        <h1>{content.title}</h1>
        <p>{content.intro}</p>
      </div>
      <div className="legal-layout">
        <aside>
            <strong>Information</strong>
            <a className={topic === "privacy" ? "active" : ""} href="#/legal/privacy">Privacy Policy <ChevronRight size={14} /></a>
            <a className={topic === "terms" ? "active" : ""} href="#/legal/terms">Terms of Service <ChevronRight size={14} /></a>
            <a className={topic === "dmca" ? "active" : ""} href="#/legal/dmca">Copyright & DMCA <ChevronRight size={14} /></a>
        </aside>
        <article>
          <div className="legal-updated">Template policy · Updated for this implementation</div>
          {content.sections.map((section, index) => (
            <section key={section.title}>
              <span>{String(index + 1).padStart(2, "0")}</span>
              <div><h2>{section.title}</h2><p>{section.body}</p></div>
            </section>
          ))}
        </article>
      </div>
    </main>
  );
}
